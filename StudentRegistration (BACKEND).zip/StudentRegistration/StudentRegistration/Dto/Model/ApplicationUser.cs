﻿using Microsoft.AspNetCore.Identity;

namespace StudentRegistration.Dto.Model
{
    public class ApplicationUser : IdentityUser
    {
    }
}
