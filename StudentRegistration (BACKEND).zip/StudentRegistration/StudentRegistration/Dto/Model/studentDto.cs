﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistration.Dto.Model
{
    public record struct studentDto(
        int id,
        string FirstName,
         string LastName,
         string MiddleName,
         string Gender,
         string DOB,
         string PhoneNumber,
         string School,
         string Department,
         string Program,
         string ProgYear,
         string studentID
        );
}
