﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistration.Dto.Model
{
    public class student
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string? FirstName { get; set; }
        [Required]
        public string? LastName { get; set; }
        public string? MiddleName { get; set; }
        public string? Gender { get; set; }
        public string? DOB { get; set; }
        public string? PhoneNumber { get; set; }
        public string? School { get; set; }
        public string? Department { get; set; }
        public string? Program { get; set; }
        public string? ProgYear { get; set; }
        public string? studentID { get; set; }
    }
}
