﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistration.Dto;
using StudentRegistration.Dto.Model;


namespace StudentRegistration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllStudent()
        {
            var students = await _context.students.ToListAsync();
            return Ok(students);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSingleStudent(int id)
        {
            var student = await _context.students.FindAsync(id);
            if (student is null)
                return BadRequest("student Not Found");
            return Ok(student);
        }
        
        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<student>> AddHotel(studentDto studentdto)
        {
            
            var newCharacter = new student
            {
                ID = studentdto.id,
                FirstName = studentdto.FirstName,
                LastName = studentdto.LastName,
                MiddleName = studentdto.MiddleName,
                Gender = studentdto.Gender,
                DOB = studentdto.DOB,
                PhoneNumber = studentdto.PhoneNumber,
                School = studentdto.School,
                Department = studentdto.Department,
                Program = studentdto.Program,
                ProgYear = studentdto.ProgYear,
                studentID = studentdto.studentID,
            };
            _context.students.Add(newCharacter);
            await _context.SaveChangesAsync();
            return Ok(new Response { Data = "record added successfully", Status = "Success", Message = "student Updated Successfully" });

        }
        [HttpPut]
        [Route("Update")]
        public async Task<IActionResult> UpdateStudent([FromBody] student stu)
        {
            var existingStudent = await _context.students.FindAsync(stu.ID);
            if (existingStudent is null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "Student  not found." });

            existingStudent.FirstName = stu.FirstName;
            existingStudent.LastName = stu.LastName;
            existingStudent.MiddleName = stu.MiddleName;
            existingStudent.Gender = stu.Gender;
            existingStudent.DOB = stu.DOB;
            existingStudent.PhoneNumber = stu.PhoneNumber;
            existingStudent.School = stu.School;
            existingStudent.Department = stu.Department;
            existingStudent.Program = stu.Program;
            existingStudent.ProgYear = stu.ProgYear;
            existingStudent.studentID = stu.studentID;

            await _context.SaveChangesAsync();
            return Ok(new Response { Data = existingStudent.ToString(), Status = "Success", Message = "student Updated Successfully" });

        }
        [HttpDelete]
        [Route("Delete")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await _context.students.FindAsync(id);
            if (student is null)
                return BadRequest("student Not Found");

            _context.students.Remove(student);
            await _context.SaveChangesAsync();
            return Ok(new Response { Data = GetAllStudent().ToString(), Status = "Success", Message = "student Updated Successfully" });

        }


    }
}
